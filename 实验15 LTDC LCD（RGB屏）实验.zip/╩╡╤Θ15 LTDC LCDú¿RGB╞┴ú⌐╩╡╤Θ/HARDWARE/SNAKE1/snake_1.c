#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "key.h"
#include "lcd.h"
#include "sdram.h"
#include "mpu.h"
#include "mpu9250.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h" 
#include "RNG.h"

#define LEFT 1
#define RIGHT 2
#define UP 3
#define DOWN 4

u8 snake1_pos = RIGHT;
u8 key;
short snake1_live = 0;
u16 snake1_x[100];
u16 snake1_y[100];
u16 snake1_speed;
u16 snake1_shape;
short i1; //����������¼�����ƶ����ʱ��
u16 apple1_x;
u16 apple1_y;
short apple1 = 0;
u16 snake1_length = 1;
short m1; //����������¼snake�ĳ���

void snake1_scan(void){  //������⼰����ȷ��
	key=KEY_Scan(0);		
		if(key){						   
				switch(key){				 
					case WKUP_PRES:
						snake1_pos = UP;
						break;
					case KEY0_PRES:
						snake1_pos = RIGHT;
						break;
					case KEY1_PRES: 
						snake1_pos = DOWN;
						break;
					case KEY2_PRES:
						snake1_pos = LEFT;
						break;
				}
			}
}

void apple1_init(void){	//ƻ������
	while(!apple1 && !RNG_Init()){
		apple1_x=RNG_Get_RandomRange(1,(lcddev.width - snake1_shape * 2) / snake1_shape / 2) * snake1_shape * 2;
		delay_ms(10);
		apple1_y=RNG_Get_RandomRange(1,(lcddev.height - snake1_shape * 2) / snake1_shape / 2) * snake1_shape * 2;
		delay_ms(10);
		apple1++;
		for(m1 = snake1_length;m1 >= 0;m1--){
		if(apple1_x == snake1_x[m1] && apple1_y == snake1_y[m1]) {apple1--;break;}
		}
	}
}

void snake1_eat(void){			//�ж��Ƿ�Ե�ƻ��
	if(snake1_x[0] == apple1_x && snake1_y[0] == apple1_y){//�ж��������������
		apple1--;
		snake1_length++;
		snake1_x[snake1_length] = snake1_x[snake1_length - 1];
		snake1_y[snake1_length] = snake1_y[snake1_length - 1];
	}
}

void snake1_move(void){	//�ƶ�
		switch(snake1_pos){
			case UP:snake1_y[0] -= snake1_shape * 2;break;
			case DOWN:snake1_y[0] += snake1_shape * 2;break;
			case LEFT:snake1_x[0] -= snake1_shape * 2;break;
			case RIGHT:snake1_x[0] += snake1_shape * 2;break;
		}
}
//
//                       _oo0oo_
//                      o8888888o
//                      88" . "88
//                      (| -_- |)
//                      0\  =  /0
//                    ___/`---'\___
//                  .' \\|     |// '.
//                 / \\|||  :  |||// \
//                / _||||| -:- |||||- \
//               |   | \\\  -  /// |   |
//               | \_|  ''\---/''  |_/ |
//               \  .-\__  '-'  ___/-. /
//             ___'. .'  /--.--\  `. .'___
//          ."" '<  `.___\_<|>_/___.' >' "".
//         | | :  `- \`.;`\ _ /`;.`/ - ` : | |
//         \  \ `_.   \_ __\ /__ _/   .-` /  /
//     =====`-.____`.___ \_____/___.-`___.-'=====
//                       `=---='
//
//
//     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
//               ���汣��         ����BUG
//
//
//

void snake1_init(u16 x,u16 y,u16 speed,u16 shape){ //�����к���
	if(x % shape != 0) snake1_x[0]=shape * 2;
	else snake1_x[0]=x;
	if(y % shape != 0) snake1_y[0]=shape * 2;
	else snake1_y[0]=y;
	snake1_speed = speed;snake1_shape = shape;
	i1 = 0;
	while(!snake1_live){
		POINT_COLOR=BLACK;
		snake1_scan();	
		if(i1<snake1_speed){
			delay_ms(10);
			i1++;
		}
		else{
			delay_ms(10);
			i1 = 0;
			snake1_eat();
			snake1_move();		
			if(snake1_y[0] < snake1_shape * 2 || snake1_y[0] > lcddev.height - snake1_shape || snake1_x[0] < snake1_shape * 2 || snake1_x[0] > lcddev.width - snake1_shape) snake1_live = 1;
			LCD_Clear(WHITE);
			apple1_init();
			while(snake1_live) {
				LCD_ShowString(lcddev.width / 2 - 40,lcddev.height / 2 - 16,200,16,16,"Game Over!");
				LCD_ShowString(lcddev.width / 2 - 100,lcddev.height / 2,200,16,16,"Press RESET To Play Again");
				POINT_COLOR=RED;
				LCD_ShowString(lcddev.width / 2 - 85,lcddev.height / 2 + 16,200,16,16,"----by luoyanpei----");
				if(KEY_Scan(0) == KEY0_PRES) {
					snake1_live=0;
					snake1_pos = RIGHT;//Ĭ���ұ�
					if(x % shape != 0) snake1_x[0]=shape * 2;
					else snake1_x[0]=x;
					if(y % shape != 0) snake1_y[0]=shape * 2;
					else snake1_y[0]=y;				
					LCD_Clear(WHITE);
			}
		}		
			if(apple1 > 0){
				POINT_COLOR=RED;
				LCD_Draw_Circle(apple1_x,apple1_y,snake1_shape);
			}
			POINT_COLOR=BLACK;
			LCD_DrawRectangle(snake1_shape - 1,snake1_shape - 1,lcddev.width - snake1_shape + 1,lcddev.height - snake1_shape + 1);
			/*
			LCD_ShowString(20,20,200,16,16,"Temp:    . C");	
			LCD_ShowString(20,40,200,16,16,"X:    . C");	
			LCD_ShowString(20,60,200,16,16,"Y:    . C");	 
			LCD_ShowString(20,80,200,16,16,"Z:    . C");*/
				for(m1 = snake1_length;m1 >= 0;m1--){
				if(m1 > 0){
					snake1_x[m1] = snake1_x[m1-1];snake1_y[m1] = snake1_y[m1-1];
				}
				LCD_Draw_Circle(snake1_x[m1],snake1_y[m1],snake1_shape);
			}
		}
	}
}
