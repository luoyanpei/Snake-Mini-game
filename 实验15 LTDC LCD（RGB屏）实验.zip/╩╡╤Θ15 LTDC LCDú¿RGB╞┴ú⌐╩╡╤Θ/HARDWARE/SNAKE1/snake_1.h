#ifndef __SNAKE_1_H
#define __SNAKE_1_H
#include "lcd.h"
#include "key.h"
#include "delay.h"
#include "rng.h"

void snake1_init(u16 x,u16 y,u16 speed,u16 shape);
void apple1_init(void);
#endif
