#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "key.h"
#include "lcd.h"
#include "sdram.h"
#include "mpu.h"
#include "mpu9250.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h" 
#include "RNG.h"

#define LEFT 1
#define RIGHT 2
#define UP 3
#define DOWN 4

u8 snake_pos = RIGHT;
float pitch,roll,yaw; 	        //ŷ����
short aacx,aacy,aacz;	        //���ٶȴ�����ԭʼ����
short gyrox,gyroy,gyroz;        //������ԭʼ���� 
short temp;		                //�¶� 
short snake_live = 0;
u16 snake_x[100];
u16 snake_y[100];
u16 snake_speed;
u16 snake_shape;
short i; //����������¼�����ƶ����ʱ��
u16 apple_x;
u16 apple_y;
short apple = 0;
u16 snake_length = 1;
short m; //����������¼snake�ĳ���

void snake_scan(void){  //������⼰����ȷ��
	if(mpu_mpl_get_data(&pitch,&roll,&yaw)==0)
        {
            temp=MPU_Get_Temperature();	//�õ��¶�ֵ
			MPU_Get_Accelerometer(&aacx,&aacy,&aacz);	//�õ����ٶȴ���������
			MPU_Get_Gyroscope(&gyrox,&gyroy,&gyroz);	//�õ�����������
			LCD_ShowString(20,20,200,16,16,"Temp:");	
			LCD_ShowString(20,40,200,16,16,"X-oy:");	
			LCD_ShowString(20,60,200,16,16,"Y-oz:");	 
			LCD_ShowString(20,80,200,16,16,"Z-oz:");
				if(temp<0)
				{
					LCD_ShowChar(20+48,20,'-',16,0);		//��ʾ����
					temp=-temp;		//תΪ����
				}else LCD_ShowChar(20+48,20,' ',16,0);		//ȥ������ 
				LCD_ShowNum(20+48+8,20,temp/100,3,16);		//��ʾ��������	    
				LCD_ShowNum(20+48+40,20,temp%10,1,16);		//��ʾС������ 
				temp=pitch*10;
				if(temp<0)
				{
					LCD_ShowChar(20+48,40,'-',16,0);		//��ʾ����
					temp=-temp;		//תΪ����
				}else LCD_ShowChar(20+48,40,' ',16,0);		//ȥ������ 
				LCD_ShowNum(20+48+8,40,temp/10,3,16);		//��ʾ��������	    
				LCD_ShowNum(20+48+40,40,temp%10,1,16);		//��ʾС������ 
				temp=roll*10;
				if(temp<0)
				{
					LCD_ShowChar(20+48,60,'-',16,0);		//��ʾ����
					temp=-temp;		//תΪ����
				}else LCD_ShowChar(20+48,60,' ',16,0);		//ȥ������ 
				LCD_ShowNum(20+48+8,60,temp/10,3,16);		//��ʾ��������	    
				LCD_ShowNum(20+48+40,60,temp%10,1,16);		//��ʾС������ 
				temp=yaw*10;
				if(temp<0)
				{
					LCD_ShowChar(20+48,80,'-',16,0);		//��ʾ����
					temp=-temp;		//תΪ����
				}else LCD_ShowChar(20+48,80,' ',16,0);		//ȥ������ 
				LCD_ShowNum(20+48+8,80,temp/10,3,16);		//��ʾ��������	    
				LCD_ShowNum(20+48+40,80,temp%10,1,16);		//��ʾС������  
				LED0_Toggle;//DS0��˸ 
				if(pitch*10<-50)snake_pos = UP;
				if(pitch*10>50)snake_pos = DOWN;
				if(roll*10<-50)snake_pos = LEFT;
				if(roll*10>50)snake_pos = RIGHT;
		}
				
}

void apple_init(void){	//ƻ������
	while(!apple && !RNG_Init()){
		apple_x=RNG_Get_RandomRange(1,(lcddev.width - snake_shape * 2) / snake_shape / 2) * snake_shape * 2;
		delay_ms(10);
		apple_y=RNG_Get_RandomRange(1,(lcddev.height - snake_shape * 2) / snake_shape / 2) * snake_shape * 2;
		delay_ms(10);
		apple++;
		for(m = snake_length;m >= 0;m--){
		if(apple_x == snake_x[m] && apple_y == snake_y[m]) {apple--;break;}
		}
	}
}

void snake_eat(void){			//�ж��Ƿ�Ե�ƻ��
	if(snake_x[0] == apple_x && snake_y[0] == apple_y){//�ж��������������
		apple--;
		snake_length++;
		snake_x[snake_length] = snake_x[snake_length - 1];
		snake_y[snake_length] = snake_y[snake_length - 1];
	}
}

void snake_move(void){	//�ƶ�
		switch(snake_pos){
			case UP:snake_y[0] -= snake_shape * 2;break;
			case DOWN:snake_y[0] += snake_shape * 2;break;
			case LEFT:snake_x[0] -= snake_shape * 2;break;
			case RIGHT:snake_x[0] += snake_shape * 2;break;
		}
}
//
//                       _oo0oo_
//                      o8888888o
//                      88" . "88
//                      (| -_- |)
//                      0\  =  /0
//                    ___/`---'\___
//                  .' \\|     |// '.
//                 / \\|||  :  |||// \
//                / _||||| -:- |||||- \
//               |   | \\\  -  /// |   |
//               | \_|  ''\---/''  |_/ |
//               \  .-\__  '-'  ___/-. /
//             ___'. .'  /--.--\  `. .'___
//          ."" '<  `.___\_<|>_/___.' >' "".
//         | | :  `- \`.;`\ _ /`;.`/ - ` : | |
//         \  \ `_.   \_ __\ /__ _/   .-` /  /
//     =====`-.____`.___ \_____/___.-`___.-'=====
//                       `=---='
//
//
//     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
//               ���汣��         ����BUG
//
//
//

void snake_init(u16 x,u16 y,u16 speed,u16 shape){ //�����к���
	if(x % shape != 0) snake_x[0]=shape * 2;
	else snake_x[0]=x;
	if(y % shape != 0) snake_y[0]=shape * 2;
	else snake_y[0]=y;
	snake_speed = speed;snake_shape = shape;
	i = 0;
	while(!snake_live){
		POINT_COLOR=BLACK;
		snake_scan();	
		if(i<snake_speed){
			delay_ms(10);
			i++;
		}
		else{
			delay_ms(10);
			i = 0;
			snake_eat();
			snake_move();		
			if(snake_y[0] < snake_shape * 2 || snake_y[0] > lcddev.height - snake_shape || snake_x[0] < snake_shape * 2 || snake_x[0] > lcddev.width - snake_shape) snake_live = 1;
			LCD_Clear(WHITE);
			apple_init();
			while(snake_live) {
				LCD_ShowString(lcddev.width / 2 - 40,lcddev.height / 2 - 16,200,16,16,"Game Over!");
				LCD_ShowString(lcddev.width / 2 - 100,lcddev.height / 2,200,16,16,"Press RESET To Play Again");
				POINT_COLOR=RED;
				LCD_ShowString(lcddev.width / 2 - 85,lcddev.height / 2 + 16,200,16,16,"----by luoyanpei----");
				if(KEY_Scan(0) == KEY0_PRES) {
					snake_live=0;
					snake_pos = RIGHT;//Ĭ���ұ�
					if(x % shape != 0) snake_x[0]=shape * 2;
					else snake_x[0]=x;
					if(y % shape != 0) snake_y[0]=shape * 2;
					else snake_y[0]=y;				
					LCD_Clear(WHITE);
			}
		}		
			if(apple > 0){
				POINT_COLOR=RED;
				LCD_Draw_Circle(apple_x,apple_y,snake_shape);
			}
			POINT_COLOR=BLACK;
			LCD_DrawRectangle(snake_shape - 1,snake_shape - 1,lcddev.width - snake_shape + 1,lcddev.height - snake_shape + 1);
			/*
			LCD_ShowString(20,20,200,16,16,"Temp:    . C");	
			LCD_ShowString(20,40,200,16,16,"X:    . C");	
			LCD_ShowString(20,60,200,16,16,"Y:    . C");	 
			LCD_ShowString(20,80,200,16,16,"Z:    . C");*/
				for(m = snake_length;m >= 0;m--){
				if(m > 0){
					snake_x[m] = snake_x[m-1];snake_y[m] = snake_y[m-1];
				}
				LCD_Draw_Circle(snake_x[m],snake_y[m],snake_shape);
			}
		}
	}
}
