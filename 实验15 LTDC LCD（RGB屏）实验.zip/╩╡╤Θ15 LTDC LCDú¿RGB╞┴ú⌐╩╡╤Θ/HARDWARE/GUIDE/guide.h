#ifndef _GUIDE_H
#define _GUIDE_H
void guide_init(void);

#endif
