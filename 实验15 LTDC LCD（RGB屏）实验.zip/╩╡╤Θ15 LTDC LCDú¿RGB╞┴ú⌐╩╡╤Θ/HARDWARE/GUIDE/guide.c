#include <guide.h>
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "key.h"
#include "lcd.h"
#include "sdram.h"
#include "mpu.h"
#include "mpu9250.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_m��otion_driver.h" 
#include "RNG.h"
#include "snake_1.h"
#include "snake.h"
void guide_init(void)
{
	int key1;
	LCD_ShowString(lcddev.width / 2 - 60,lcddev.height / 2 - 30,200,16,16,"Select a Mode:");
	LCD_ShowString(lcddev.width / 2 - 90,lcddev.height / 2-16,200,16,16,"    Key Mode:KEY1    ");
	LCD_ShowString(lcddev.width / 2 - 60,lcddev.height / 2 ,200,16,16,"MPU Mode :KEY0");
	LCD_ShowString(lcddev.width / 2 - 60,lcddev.height / 2 + 16,200,16,16,"Rock Mode(test) :KEY2");
	delay_ms(1000);
	while(1){
	key1=KEY_Scan(0);	
	if(key1){						   
				switch(key1){				 
					case KEY0_PRES:
						snake_init(30,30,100,20); 
					case KEY1_PRES: 
						snake1_init(30,30,50,20); 
				}
			}
		}
}